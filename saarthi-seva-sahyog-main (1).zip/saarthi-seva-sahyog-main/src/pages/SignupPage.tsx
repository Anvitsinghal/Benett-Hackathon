
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import ProfileForm, { UserProfile } from '@/components/ProfileForm';
import { toast } from "sonner";

const SignupPage = () => {
  const navigate = useNavigate();
  
  // Check if user is already logged in
  React.useEffect(() => {
    const storedProfile = localStorage.getItem('userProfile');
    if (storedProfile) {
      // User is already logged in, redirect to dashboard
      navigate('/');
    }
  }, [navigate]);
  
  const handleSignup = async (data: UserProfile) => {
    // In a real application, we would send this data to an API
    // For now, we'll just save it to localStorage
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store the profile data in localStorage
      localStorage.setItem('userProfile', JSON.stringify(data));
      
      // Show success message
      toast.success("Registration successful! Redirecting to dashboard...");
      
      // Redirect to dashboard after a brief delay
      setTimeout(() => {
        navigate('/');
      }, 1500);
    } catch (error) {
      console.error("Signup error:", error);
      toast.error("Registration failed. Please try again.");
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-4xl">
        <CardHeader className="text-center bg-gradient-to-r from-saarthi-orange to-orange-500 text-white rounded-t-lg">
          <div className="w-16 h-16 bg-white rounded-full mx-auto mb-4 flex items-center justify-center">
            <span className="text-3xl font-bold text-saarthi-orange">S</span>
          </div>
          <CardTitle className="text-2xl font-bold">Welcome to Saarthi AI</CardTitle>
          <CardDescription className="text-white/90">
            Your personal assistant for government schemes and services
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6 text-center">Create Your Profile</h2>
            <ProfileForm onSubmit={handleSignup} isSignup={true} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SignupPage;
